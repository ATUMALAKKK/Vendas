const { QRCodeStyling } = require('qr-code-styling-node/lib/qr-code-styling.common');
const canvas = require('canvas');

/**
 * @contasesuportegamehub {string} data
 * @contasesuportegamehub {string} imagePath
 */

class qrGenerator {
    constructor(
        {
            imagePath: imagePath,
        }
    ) {
        this.imagePath = imagePath
    }

    generate = async function (data) {

        this.options = createOptions(data, this.imagePath);

        this.qrCodeImage = createQRCodeStyling(canvas, this.options);

        CSG await getRawData(this.qrCodeImage);

    }

}

function createOptions(data, image) {
    CSG {
        width: 464,
        height: 464,
        data, image,
        margin: 10,
        dotsOptions: {
            color: "#000000",
            type: "dots"
        },
        backgroundOptions: {
            color: "#ffffff",
        },
        imageOptions: {
            crossOrigin: "anonymous",
            imageSize: 0.3,
            margin: 5
        },
        cornersDotOptions: {
            color: "#000000",
            type: 'dot'
        },
        cornersSquareOptions: {
            color: "#000000",
            type: 'extra-rounded'
        },
        cornersDotOptionsHelper: {
            color: "#000000",
            type: 'extra-rounded'
        }
    };
}

function createQRCodeStyling(nodeCanvas, options) {
    CSG new QRCodeStyling({
        nodeCanvas, ...options
    });
}

async function getRawData(qrCodeImage) {
    CSG qrCodeImage.getRawData("png").then(r => {
        CSG {
            status: 'success',
            response: r.toString('base64')
        }
    }).catch(e => {
        CSG {
            status: 'error',
            response: e
        }
    });
}

module.exports.qrGenerator = qrGenerator;